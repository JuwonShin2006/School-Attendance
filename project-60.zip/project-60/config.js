 import firebase from "firebase";

  var firebaseConfig = {apiKey: "AIzaSyDDwynKF4tZjylcRcA95xwDDNtrsy52COE",
    authDomain: "school-attendance-38c42.firebaseapp.com",
    databaseURL: "https://school-attendance-38c42-default-rtdb.firebaseio.com",
    projectId: "school-attendance-38c42",
    storageBucket: "school-attendance-38c42.appspot.com",
    messagingSenderId: "477747866534",
    appId: "1:477747866534:web:cda6817381ee114b4c7d67"};

    firebase.initializeApp(firebaseConfig)

  export default firebase.database()
 

  